﻿#pragma once

#include <chrono>

#include "framework.h"

class keyboard_window : public window
{
	static int constexpr width = 600;
	static int constexpr height = 250;

	std::chrono::time_point<std::chrono::steady_clock> begin;

public:
	keyboard_window(window_class* wndClass);
	LRESULT window_proc(UINT, WPARAM, LPARAM) override;
	friend class game_window;
};

class game_window : public window
{
	static int constexpr width = 200;
	static int constexpr height = 250;

	keyboard_window& m_parent;

public:
	game_window(window_class* wndClass, keyboard_window& parent);
	LRESULT window_proc(UINT, WPARAM, LPARAM) override;
};
