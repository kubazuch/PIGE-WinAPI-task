#pragma once

#include <string>

#include "framework.h"

// https://github.com/planetchili/hw3d/blob/831380f6394cdf043069fba1e371cce6ba8ebf13/hw3d/ChiliException.h

class PIGEException : public std::exception
{
public:
	PIGEException(int line, const char* file) noexcept : line{ line }, file{ file } {}
	const char* what() const noexcept override;
	virtual std::string get_origin_string() const noexcept;
private:
	int line;
	std::string file;
protected:
	mutable std::string whatBuffer;
};

class WinAPIException : public PIGEException
{
public:
	WinAPIException(int line, const char* file, HRESULT hr) noexcept : PIGEException{ line, file }, hr{ hr } {}
	const char* what() const noexcept override;
	static std::string translate_error_code(HRESULT hr) noexcept;
	HRESULT get_error_code() const noexcept;
	std::string get_error_string() const noexcept;
private:
	HRESULT hr;
};