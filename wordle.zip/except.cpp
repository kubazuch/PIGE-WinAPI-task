#include "except.h"

#include <sstream>

const char* PIGEException::what() const noexcept
{
	std::ostringstream oss;
	oss << get_origin_string();
	whatBuffer = oss.str();
	return whatBuffer.c_str();
}

std::string PIGEException::get_origin_string() const noexcept
{
	std::ostringstream oss;
	oss << "[File] " << file << std::endl
		<< "[Line] " << line;

	return oss.str();
}

std::string WinAPIException::translate_error_code(HRESULT hr) noexcept
{
	char* pMsgBuf = nullptr;
	const DWORD nMsgLen = FormatMessageA(FORMAT_MESSAGE_ALLOCATE_BUFFER
		| FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
		nullptr, hr, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		reinterpret_cast<LPSTR>(&pMsgBuf), 0, nullptr);

	if (nMsgLen == 0)
		return "Unidentified error";

	std::string error = pMsgBuf;
	LocalFree(pMsgBuf);
	return error;
}

const char* WinAPIException::what() const noexcept
{
	std::ostringstream oss;
	oss << "[Error Code] 0x" << std::hex << std::uppercase << get_error_code()
		<< std::dec << " (" << static_cast<unsigned long>(get_error_code()) << ")" << std::endl
		<< "[Description] " << get_error_string() << std::endl
		<< get_origin_string();
	whatBuffer = oss.str();
	return whatBuffer.c_str();
}

HRESULT WinAPIException::get_error_code() const noexcept
{
	return hr;
}

std::string WinAPIException::get_error_string() const noexcept
{
	return translate_error_code(hr);
}




