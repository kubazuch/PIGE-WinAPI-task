﻿#include "wordle.h"

#pragma region keyboard

keyboard_window::keyboard_window(window_class* wndClass)
	: window{}
{
	m_wndClass = wndClass;

	CreateWindowExW(WS_EX_LAYERED,
		wndClass->getName(),
		L"WORDLE - KEYBOARD",
		WS_OVERLAPPED | WS_SYSMENU | WS_CAPTION | WS_MINIMIZEBOX,
		(SCREEN_WIDTH - width) / 2,
		SCREEN_HEIGHT - height - 100,
		width,
		height,
		nullptr,
		nullptr,
		wndClass->getInstance(),
		reinterpret_cast<LPVOID>(this));

	SetLayeredWindowAttributes(m_hWnd, 0, 255 * 0.5, LWA_ALPHA);
}


LRESULT keyboard_window::window_proc(UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
	case WM_CREATE:
		begin = std::chrono::high_resolution_clock::now();
		SetTimer(m_hWnd, 13, 25, nullptr);
		break;
	case WM_TIMER:
		if (wParam == 13)
		{
			static wchar_t title[100];

			const auto end = std::chrono::high_resolution_clock::now();
			const auto elapsed = std::chrono::duration_cast<std::chrono::microseconds>(end - begin);
			_snwprintf_s(title, 100, L"WORDLE - KEYBOARD: %.5f", elapsed.count() * 1e-6);
			SetWindowText(m_hWnd, title);
		}
		break;
	default:
		return window::window_proc(msg, wParam, lParam);
	}

	return 0;
}

#pragma endregion

#pragma region game

game_window::game_window(window_class* wndClass, keyboard_window& parent)
	: window{}, m_parent{ parent }
{
	m_wndClass = wndClass;

	CreateWindowExW(0,
		wndClass->getName(),
		L"WORDLE - PUZZLE",
		WS_OVERLAPPED | WS_CAPTION,
		(SCREEN_WIDTH - width) / 2,
		(SCREEN_HEIGHT - height) / 2 ,
		width,
		height,
		parent.m_hWnd,
		nullptr,
		wndClass->getInstance(),
		reinterpret_cast<LPVOID>(this));
}

LRESULT game_window::window_proc(UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
	default:
		return window::window_proc(msg, wParam, lParam);
	}

	return 0;
}
#pragma endregion