// main.cpp : Defines the entry point for the application.
//

#include "wordle.h"

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
	_In_opt_ HINSTANCE hPrevInstance,
	_In_ LPWSTR    lpCmdLine,
	_In_ int       nCmdShow)
{
	window::window_class keyboard_class = window::window_class::build(hInstance, L"KEYBOARD")
		.withIcon(LoadIcon(hInstance, MAKEINTRESOURCE(IDI_WORDLE)))
		.withCursor(LoadCursor(nullptr, L"IDC_ARROW"))
		.withMenu(MAKEINTRESOURCE(IDC_WORDLE));

	window::window_class game_class = window::window_class::build(hInstance, L"GAME")
		.withIcon(LoadIcon(hInstance, MAKEINTRESOURCE(IDI_WORDLE)))
		.withCursor(LoadCursor(nullptr, L"IDC_ARROW"));

	keyboard_window keyboard = keyboard_window(&keyboard_class);
	game_window game = game_window(&game_class, keyboard);
	keyboard.show(nCmdShow);
	game.show(SW_SHOWNA);

	HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_WORDLE));

	MSG msg;

	// Main message loop:
	while (GetMessage(&msg, nullptr, 0, 0))
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return 0;
}