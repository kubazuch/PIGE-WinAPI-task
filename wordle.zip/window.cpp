#include "window.h"

#include "resource.h"

window::window(window_class* wClass, const std::wstring& title)
	: m_hWnd{ nullptr }, m_wndClass{ wClass }
{
	int x = GetSystemMetrics(SM_CXSCREEN);
	int y = GetSystemMetrics(SM_CYSCREEN);

	KUZU_ASSERT(CreateWindowExW(0, wClass->getName(), title.c_str(), WS_OVERLAPPEDWINDOW | WS_VISIBLE,
		x/4, y/4, x/2, y/2,
		nullptr, nullptr, wClass->getInstance(), reinterpret_cast<LPVOID>(this)));
}

window::~window()
{
	if (m_hWnd)
		DestroyWindow(m_hWnd);
}

LRESULT window::window_proc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	window* w = nullptr;
	if (msg == WM_NCCREATE)
	{
		auto pcs = reinterpret_cast<LPCREATESTRUCTW>(lParam);
		w = static_cast<window*>(pcs->lpCreateParams);
		SetWindowLongPtrW(hWnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(w));
		w->m_hWnd = hWnd;
	}
	else
		w = reinterpret_cast<window*>(GetWindowLongPtrW(hWnd, GWLP_USERDATA));

	if (w)
	{
		auto r = w->window_proc(msg, wParam, lParam);
		if (msg == WM_NCDESTROY)
		{
			w->m_hWnd = nullptr;
			SetWindowLongPtrW(hWnd, GWLP_USERDATA, 0);
		}
		return r;
	}

	return DefWindowProcW(hWnd, msg, wParam, lParam);
}

LRESULT window::window_proc(UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
	case WM_CLOSE:
		DestroyWindow(m_hWnd);
		return 0;
	case WM_DESTROY:
		PostQuitMessage(EXIT_SUCCESS);
		return 0;
	default:
		return DefWindowProcW(m_hWnd, msg, wParam, lParam);
	}

	return 0;
}

BOOL window::show(int nCmdShow) const
{
	return ShowWindow(m_hWnd, nCmdShow);
}


#pragma region window_class

window::window_class::window_class(WNDCLASSEXW wcx)
	: m_hInstance{ wcx.hInstance }, m_lpszClassName{ wcx.lpszClassName }
{
	KUZU_ASSERT(RegisterClassExW(&wcx));
}

window::window_class::~window_class()
{
	UnregisterClassW(m_lpszClassName, m_hInstance);
}

#pragma endregion

#pragma region builder

window::window_class::builder::builder(HINSTANCE hInstance, LPCWSTR lpszClassName)
{
	WNDCLASSEXW wcx;
	if (GetClassInfoExW(hInstance, lpszClassName, &wcx))
		throw KUZU_EXCEPT();

	m_wcx.lpszClassName = lpszClassName;
	m_wcx.hInstance = hInstance;
}

window::window_class::builder& window::window_class::builder::withStyle(UINT style)
{
	m_wcx.style = style;
	return *this;
}

window::window_class::builder& window::window_class::builder::withWndProc(WNDPROC wndProc)
{
	m_wcx.lpfnWndProc = wndProc;
	return *this;
}

window::window_class::builder& window::window_class::builder::withClsExtra(int clsExtra)
{
	m_wcx.cbClsExtra = clsExtra;
	return *this;
}

window::window_class::builder& window::window_class::builder::withWndExtra(int wndExtra)
{
	m_wcx.cbWndExtra = wndExtra;
	return *this;
}

window::window_class::builder& window::window_class::builder::withIcon(HICON icon, HICON small)
{
	m_wcx.hIcon = icon;
	m_wcx.hIconSm = small;
	return *this;
}

window::window_class::builder& window::window_class::builder::withCursor(HCURSOR cursor)
{
	m_wcx.hCursor = cursor;
	return *this;
}

window::window_class::builder& window::window_class::builder::withBackground(HBRUSH hBrush)
{
	m_wcx.hbrBackground = hBrush;
	return *this;
}

window::window_class::builder& window::window_class::builder::withMenu(LPCWSTR menu)
{
	m_wcx.lpszMenuName = menu;
	return *this;
}

#pragma endregion





